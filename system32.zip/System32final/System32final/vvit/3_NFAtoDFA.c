#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define MAX_STATES 20
#define MAX_ALPHABET 10

int nfa_states, alphabet_size;
char alphabet[MAX_ALPHABET];
int nfa_transitions[MAX_STATES][MAX_ALPHABET][MAX_STATES];
int nfa_final_states[MAX_STATES];
int num_nfa_final;

int dfa_states_count = 0;
int dfa_transitions[1 << MAX_STATES][MAX_ALPHABET];
int dfa_final[1 << MAX_STATES];
int visited[1 << MAX_STATES];

/* Check if a set of NFA states contains any final state */
int contains_final_state(int state_set) {
    for (int i = 0; i < nfa_states; i++) {
        if ((state_set & (1 << i)) && nfa_final_states[i]) return 1;
    }
    return 0;
}

/* Print subset as {0,2,3} */
void print_set(int state_set) {
    printf("{");
    int first = 1;
    for (int i = 0; i < nfa_states; i++) {
        if (state_set & (1 << i)) {
            if (!first) printf(",");
            printf("%d", i);
            first = 0;
        }
    }
    printf("}");
}

/* Get next NFA set for a given symbol */
int move(int state_set, int symbol_index) {
    int new_set = 0;
    for (int st = 0; st < nfa_states; st++) {
        if (state_set & (1 << st)) {
            for (int nx = 0; nx < nfa_states; nx++) {
                if (nfa_transitions[st][symbol_index][nx])
                    new_set |= (1 << nx);
            }
        }
    }
    return new_set;
}

int main() {
    printf("Enter number of NFA states: ");
    scanf("%d", &nfa_states);

    printf("Enter number of alphabet symbols: ");
    scanf("%d", &alphabet_size);

    printf("Enter alphabet symbols: ");
    for (int i = 0; i < alphabet_size; i++) scanf(" %c", &alphabet[i]);

    /* Initialize transition table */
    for (int i = 0; i < nfa_states; i++)
        for (int j = 0; j < alphabet_size; j++)
            for (int k = 0; k < nfa_states; k++)
                nfa_transitions[i][j][k] = 0;

    printf("\nEnter transitions (NFA):\n");
    printf("Format: state input_symbol next_state\n");
    printf("Enter -1 x -1 to stop.\n");

    while (1) {
        int s, ns;
        char sym;
        scanf("%d %c %d", &s, &sym, &ns);
        if (s == -1 && ns == -1) break;

        int index = -1;
        for (int i = 0; i < alphabet_size; i++)
            if (alphabet[i] == sym) index = i;

        if (index == -1) {
            printf("Invalid symbol.\n");
            continue;
        }

        nfa_transitions[s][index][ns] = 1;
    }

    printf("Enter number of NFA final states: ");
    scanf("%d", &num_nfa_final);

    printf("Enter final states: ");
    for (int i = 0; i < nfa_states; i++) nfa_final_states[i] = 0;
    for (int i = 0; i < num_nfa_final; i++) {
        int x;
        scanf("%d", &x);
        nfa_final_states[x] = 1;
    }

    printf("\n----- DFA CONVERSION STARTED -----\n");

    int queue[1 << MAX_STATES], front = 0, rear = 0;

    /* Start DFA with {0} */
    int start_set = 1 << 0;
    queue[rear++] = start_set;
    visited[start_set] = 1;

    while (front < rear) {
        int current = queue[front++];

        for (int i = 0; i < alphabet_size; i++) {
            int nxt = move(current, i);
            dfa_transitions[current][i] = nxt;

            if (!visited[nxt] && nxt != 0) {
                visited[nxt] = 1;
                queue[rear++] = nxt;
            }
        }
    }

    printf("\n----- DFA TRANSITION TABLE -----\n");
    printf("DFA State\t");
    for (int i = 0; i < alphabet_size; i++) printf("%c\t", alphabet[i]);
    printf("Final?\n");

    for (int st = 0; st < (1 << nfa_states); st++) {
        if (!visited[st]) continue;

        print_set(st);
        printf("\t");

        for (int i = 0; i < alphabet_size; i++) {
            print_set(dfa_transitions[st][i]);
            printf("\t");
        }

        printf("%s\n", contains_final_state(st) ? "Yes" : "No");
    }

    /* Test input strings */
    while (1) {
        char str[100];
        printf("\nEnter string to test (type exit to stop): ");
        scanf("%s", str);
        if (strcmp(str, "exit") == 0) break;

        int current = start_set;

        for (int i = 0; str[i] != '\0'; i++) {
            char sym = str[i];
            int index = -1;

            for (int j = 0; j < alphabet_size; j++)
                if (alphabet[j] == sym) index = j;

            if (index == -1) {
                printf("Invalid symbol '%c'. Rejected.\n", sym);
                current = -1;
                break;
            }

            current = dfa_transitions[current][index];
        }

        if (current != -1 && contains_final_state(current))
            printf("String ACCEPTED by DFA.\n");
        else
            printf("String REJECTED by DFA.\n");
    }

    return 0;
}