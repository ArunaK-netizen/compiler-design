#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX 20

char grammar[10][MAX];
int prodCount;

char nonTerminals[MAX];
int ntCount = 0;

char terminals[MAX];
int tCount = 0;

char parseTable[10][10][MAX];

// check if char is non-terminal
int isNonTerminal(char c) {
    return isupper(c);
}

// add symbol to set
void addToSet(char set[], char c) {
    if (!strchr(set, c)) {
        int len = strlen(set);
        set[len] = c;
        set[len+1] = '\0';
    }
}

// FIRST function
void findFirst(char *res, char c) {
    if (!isNonTerminal(c)) {
        addToSet(res, c);
        return;
    }
    for (int i=0;i<prodCount;i++) {
        if (grammar[i][0]==c) {
            char *rhs = strchr(grammar[i],'=')+1;
            char temp[MAX];
            while (rhs) {
                memset(temp,0,sizeof(temp));
                if (rhs[0]=='e') {
                    addToSet(res,'e');
                } else {
                    for (int k=0; rhs[k] && rhs[k] != '|'; k++) {
                        findFirst(temp,rhs[k]);
                        int hasE=0;
                        for (int j=0; temp[j]; j++) {
                            if (temp[j]=='e') hasE=1;
                            else addToSet(res,temp[j]);
                        }
                        if (!hasE) break;
                        if (rhs[k+1]=='\0' || rhs[k+1]=='|') addToSet(res,'e');
                        if (!isNonTerminal(rhs[k])) break;
                    }
                }
                rhs = strchr(rhs,'|');
                if (rhs) rhs++;
            }
        }
    }
}

// FOLLOW function
void findFollow(char *res, char c) {
    if (c==nonTerminals[0]) addToSet(res,'$');
    for (int i=0;i<prodCount;i++) {
        char lhs=grammar[i][0];
        char *rhs=strchr(grammar[i],'=')+1;
        for (int k=0; rhs[k]; k++) {
            if (rhs[k]==c) {
                if (rhs[k+1] && rhs[k+1] != '|') {
                    char temp[MAX]="";
                    findFirst(temp,rhs[k+1]);
                    int hasE=0;
                    for (int j=0; temp[j]; j++) {
                        if (temp[j]=='e') hasE=1;
                        else addToSet(res,temp[j]);
                    }
                    if (hasE) {
                        char temp2[MAX]="";
                        findFollow(temp2,lhs);
                        for (int j=0; temp2[j]; j++) addToSet(res,temp2[j]);
                    }
                } else {
                    if (lhs!=c) {
                        char temp2[MAX]="";
                        findFollow(temp2,lhs);
                        for (int j=0; temp2[j]; j++) addToSet(res,temp2[j]);
                    }
                }
            }
        }
    }
}

// find index in array
int indexOf(char arr[], int n, char c) {
    for (int i=0;i<n;i++) if (arr[i]==c) return i;
    return -1;
}

// build parse table
void buildParseTable() {
    for (int i=0;i<prodCount;i++) {
        char lhs=grammar[i][0];
        char *rhsAll=strchr(grammar[i],'=')+1;
        char *rhs=rhsAll;
        while (rhs) {
            char alt[MAX]; int m=0;
            while (rhs[m] && rhs[m]!='|') { alt[m]=rhs[m]; m++; }
            alt[m]='\0';

            char temp[MAX]="";
            findFirst(temp,alt[0]);
            int row=indexOf(nonTerminals,ntCount,lhs);
            int hasE=0;
            for (int j=0; temp[j]; j++) {
                if (temp[j]=='e') hasE=1;
                else {
                    int col=indexOf(terminals,tCount,temp[j]);
                    strcpy(parseTable[row][col],alt);
                }
            }
            if (hasE) {
                char temp2[MAX]="";
                findFollow(temp2,lhs);
                for (int j=0; temp2[j]; j++) {
                    int col=indexOf(terminals,tCount,temp2[j]);
                    strcpy(parseTable[row][col],"e");
                }
            }
            rhs=strchr(rhs,'|');
            if (rhs) rhs++;
        }
    }
}

// predictive parser
void predictiveParse(const char *input) {
    char stack[MAX];
    int top=-1;
    stack[++top]='$';
    stack[++top]=nonTerminals[0];
    int ip=0;
    char a=input[ip];

    printf("\n%-20s %-20s %-20s\n","STACK","INPUT","ACTION");
    printf("------------------------------------------------------------\n");

    while (top>=0) {
        for (int i=0;i<=top;i++) printf("%c",stack[i]);
        printf("%*s",20-(top+1),"");
        printf("%-20s",input+ip);

        char X=stack[top--];
        if (isNonTerminal(X)) {
            int row=indexOf(nonTerminals,ntCount,X);
            int col=indexOf(terminals,tCount,a);
            if (row==-1||col==-1||strlen(parseTable[row][col])==0) {
                printf("Error\n");
                return;
            }
            char *rhs=parseTable[row][col];
            printf("%c->%s\n",X,rhs);
            if (rhs[0]!='e') {
                int len=strlen(rhs);
                for (int k=len-1;k>=0;k--) stack[++top]=rhs[k];
            }
        } else {
            if (X==a) {
                printf("match %c\n",a);
                ip++; a=input[ip];
            } else {
                printf("Error\n");
                return;
            }
        }
        if (X=='$' && a=='$') {
            printf("Input Accepted!\n");
            return;
        }
    }
}

int main() {
    printf("Enter number of productions: ");
    scanf("%d",&prodCount);
    getchar(); // consume newline

    printf("Enter productions (e.g., E=TR or R=+TR|e):\n");
    for (int i=0;i<prodCount;i++) {
        fgets(grammar[i], MAX, stdin);
        grammar[i][strcspn(grammar[i], "\n")] = '\0';
    }

    printf("\nEnter non-terminals (no spaces, e.g., ERTYF): ");
    scanf("%s", nonTerminals);
    ntCount = strlen(nonTerminals);

    printf("Enter terminals (no spaces, e.g., +*()i$): ");
    scanf("%s", terminals);
    tCount = strlen(terminals);

    buildParseTable();

    char input[MAX];
    printf("\nEnter input string ending with $: ");
    scanf("%s",input);
    predictiveParse(input);

    return 0;
}
