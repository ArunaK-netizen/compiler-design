#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MAX_TOKENS 100

// Function to check if a character is a delimiter
bool isDelimiter(char ch) {
    return (ch == ' ' || ch == '+' || ch == '-' || ch == '*' || ch == '/' ||
            ch == ',' || ch == ';' || ch == '>' || ch == '<' || ch == '=' ||
            ch == '(' || ch == ')' || ch == '[' || ch == ']' || ch == '{' || ch == '}');
}

// Function to check if a character is an operator
bool isOperator(char ch) {
    return (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '>' ||
            ch == '<' || ch == '=');
}

// Function to check if a string is a keyword
bool isKeyword(const char *str) {
    const char *keywords[] = {"int", "float", "if", "return", NULL};
    for (int i = 0; keywords[i] != NULL; i++) {
        if (strcmp(str, keywords[i]) == 0) {
            return true;
        }
    }
    return false;
}

// Function to check if a string is a valid integer
bool isInteger(const char *str) {
    for (int i = 0; i < strlen(str); i++) {
        if (str[i] < '0' || str[i] > '9') return false;
    }
    return true;
}

// Function to check if a string is a real number
bool isRealNumber(const char *str) {
    bool hasDecimal = false;
    for (int i = 0; i < strlen(str); i++) {
        if (str[i] == '.') {
            if (hasDecimal) return false;
            hasDecimal = true;
        } else if (str[i] < '0' || str[i] > '9') {
            return false;
        }
    }
    return hasDecimal;
}

// Function to validate a string as an identifier
bool validIdentifier(const char *str) {
    return !(str[0] >= '0' && str[0] <= '9') && !isDelimiter(str[0]);
}

// Function to extract a substring from a given string
char* subString(const char *str, int left, int right) {
    char *subStr = (char *)malloc(sizeof(char) * (right - left + 2));
    for (int i = left; i <= right; i++) {
        subStr[i - left] = str[i];
    }
    subStr[right - left + 1] = '\0';
    return subStr;
}

// Function to write tokens to an output file
void writeToOutputFile(char keywords[MAX_TOKENS][50], int kwCount,
                       char identifiers[MAX_TOKENS][50], int idCount,
                       char operators[MAX_TOKENS][5], int opCount,
                       char integers[MAX_TOKENS][50], int intCount,
                       char reals[MAX_TOKENS][50], int realCount) {
    FILE *outputFile = fopen("output.txt", "w");
    if (!outputFile) {
        printf("Error opening output file!\n");
        return;
    }

    fprintf(outputFile, "Keywords: ");
    for (int i = 0; i < kwCount; i++) fprintf(outputFile, "%s ", keywords[i]);
    fprintf(outputFile, "\n");

    fprintf(outputFile, "Identifiers: ");
    for (int i = 0; i < idCount; i++) fprintf(outputFile, "%s ", identifiers[i]);
    fprintf(outputFile, "\n");

    fprintf(outputFile, "Operators: ");
    for (int i = 0; i < opCount; i++) fprintf(outputFile, "%s ", operators[i]);
    fprintf(outputFile, "\n");

    fprintf(outputFile, "Integers: ");
    for (int i = 0; i < intCount; i++) fprintf(outputFile, "%s ", integers[i]);
    fprintf(outputFile, "\n");

    fprintf(outputFile, "Real Numbers: ");
    for (int i = 0; i < realCount; i++) fprintf(outputFile, "%s ", reals[i]);
    fprintf(outputFile, "\n");

    fclose(outputFile);
}

// Function to parse the input string and classify tokens
void parse(char *str, char keywords[MAX_TOKENS][50], int *kwCount,
           char identifiers[MAX_TOKENS][50], int *idCount,
           char operators[MAX_TOKENS][5], int *opCount,
           char integers[MAX_TOKENS][50], int *intCount,
           char reals[MAX_TOKENS][50], int *realCount) {
    int left = 0, right = 0, len = strlen(str);
    while (right <= len && left <= right) {
        if (!isDelimiter(str[right])) {
            right++;
        }
        if (isDelimiter(str[right]) && left == right) {
            if (isOperator(str[right])) {
                char op[2] = {str[right], '\0'};
                strcpy(operators[(*opCount)++], op);
            }
            right++;
            left = right;
        } else if ((isDelimiter(str[right]) && left != right) || (right == len && left != right)) {
            char *subStr = subString(str, left, right - 1);
            if (isKeyword(subStr)) {
                strcpy(keywords[(*kwCount)++], subStr);
            } else if (isInteger(subStr)) {
                strcpy(integers[(*intCount)++], subStr);
            } else if (isRealNumber(subStr)) {
                strcpy(reals[(*realCount)++], subStr);
            } else if (validIdentifier(subStr)) {
                strcpy(identifiers[(*idCount)++], subStr);
            }
            free(subStr);
            left = right;
        }
    }
}

// Function to get user input and save it to a file
void userInputToFile() {
    FILE *inputFile = fopen("input.txt", "w");
    if (!inputFile) {
        printf("Error opening input file!\n");
        return;
    }
    printf("Enter program code (end with Ctrl+D):\n");
    char input[100];
    while (fgets(input, sizeof(input), stdin)) {
        fprintf(inputFile, "%s", input);
    }
    fclose(inputFile);
}

// Main function to control the flow
int main() {
    char input[1000];
    char keywords[MAX_TOKENS][50], identifiers[MAX_TOKENS][50],
         operators[MAX_TOKENS][5], integers[MAX_TOKENS][50], reals[MAX_TOKENS][50];
    int kwCount = 0, idCount = 0, opCount = 0, intCount = 0, realCount = 0;

    userInputToFile();

    FILE *inputFile = fopen("input.txt", "r");
    if (!inputFile) {
        printf("Error opening input file!\n");
        return 1;
    }

    while (fgets(input, sizeof(input), inputFile)) {
        parse(input, keywords, &kwCount, identifiers, &idCount, operators, &opCount, integers, &intCount, reals, &realCount);
    }

    fclose(inputFile);

    writeToOutputFile(keywords, kwCount, identifiers, idCount, operators, opCount, integers, intCount, reals, realCount);

    printf("Results have been written to output.txt.\n");

    return 0;
}