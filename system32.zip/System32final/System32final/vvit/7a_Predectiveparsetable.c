#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

#define MAX_PRODS 128
#define MAX_ALTS 16
#define MAX_RHS 64
#define MAX_NT 26
#define MAX_TERMS 128

typedef struct {
    char lhs;
    char rhs[MAX_ALTS][MAX_RHS];
    int n_alts;
} Production;

static Production prods[MAX_PRODS];
static int prod_count = 0;

static bool nt_present[MAX_NT];
static char nt_list[MAX_NT];
static int nt_cnt = 0;

static char term_list[MAX_TERMS];
static int term_cnt = 0;

static bool FIRST[MAX_NT][MAX_TERMS + 1];
static bool FOLLOW[MAX_NT][MAX_TERMS];
static bool nullable_nt[MAX_NT];

static int term_index[256];
static int nt_index[256];

static char parse_table[MAX_NT][MAX_TERMS][MAX_RHS];
static bool table_filled[MAX_NT][MAX_TERMS];

static inline bool is_nonterminal(char c){ return c>='A' && c<='Z'; }
static inline bool is_epsilon_char(char c){ return c=='e'; }

static bool is_terminal_char(char c){
    if (c=='|' || c=='-' || c=='>' || c=='\0') return false;
    if (is_nonterminal(c)) return false;
    if (is_epsilon_char(c)) return false;
    return true;
}

static void add_nt(char A){
    if (!is_nonterminal(A)) return;
    if (!nt_present[A-'A']){
        nt_present[A-'A'] = true;
        nt_list[nt_cnt++] = A;
    }
}

static bool term_exists(char t){
    for (int i=0;i<term_cnt;i++) if (term_list[i]==t) return true;
    return false;
}

static void add_term(char t){
    if (!term_exists(t)){
        term_list[term_cnt++] = t;
    }
}

static void init_indices(void){
    for (int i=0;i<256;i++){ term_index[i] = -1; nt_index[i] = -1; }
    for (int i=0;i<term_cnt;i++) term_index[(unsigned char)term_list[i]] = i;
    for (int i=0;i<nt_cnt;i++) nt_index[(unsigned char)nt_list[i]] = i;
}

static bool first_of_sequence(const char *alpha, bool *out_first_term){
    for (int i=0;i<MAX_TERMS;i++) out_first_term[i]=false;
    int len = (int)strlen(alpha);
    if (len==1 && is_epsilon_char(alpha[0])) return true;

    for (int pos=0; pos<len; pos++){
        char X = alpha[pos];
        if (is_terminal_char(X)){
            int ti = term_index[(unsigned char)X];
            if (ti>=0) out_first_term[ti] = true;
            return false;
        } else if (is_nonterminal(X)){
            int xi = nt_index[(unsigned char)X];
            for (int t=0;t<term_cnt;t++){
                if (FIRST[xi][t]) out_first_term[t] = true;
            }
            if (FIRST[xi][MAX_TERMS]) continue;
            else return false;
        } else if (is_epsilon_char(X)){
            continue;
        }
    }
    return true;
}

static void compute_symbol_sets(void){
    for (int i=0;i<prod_count;i++){
        for (int j=0;j<prods[i].n_alts;j++){
            const char *rhs = prods[i].rhs[j];
            int L = (int)strlen(rhs);
            if (L==1 && is_epsilon_char(rhs[0])) continue;
            for (int k=0;k<L;k++){
                char c = rhs[k];
                if (is_terminal_char(c)) add_term(c);
            }
        }
    }
    add_term('$');
}

static void compute_first(void){
    memset(nullable_nt, 0, sizeof(nullable_nt));
    for (int i=0;i<MAX_NT;i++)
        for (int j=0;j<=MAX_TERMS;j++) FIRST[i][j] = false;

    bool changed = true;
    while (changed){
        changed = false;
        for (int p=0;p<prod_count;p++){
            int A = nt_index[(unsigned char)prods[p].lhs];
            for (int a=0;a<prods[p].n_alts;a++){
                const char *alpha = prods[p].rhs[a];
                bool temp_terms[MAX_TERMS];
                bool eps = first_of_sequence(alpha, temp_terms);
                for (int t=0;t<term_cnt;t++){
                    if (temp_terms[t] && !FIRST[A][t]){
                        FIRST[A][t]=true; changed=true;
                    }
                }
                if (eps && !FIRST[A][MAX_TERMS]){
                    FIRST[A][MAX_TERMS]=true; changed=true;
                }
            }
        }
    }
    for (int i=0;i<nt_cnt;i++) nullable_nt[i] = FIRST[i][MAX_TERMS];
}

static void compute_follow(void){
    for (int i=0;i<nt_cnt;i++)
        for (int t=0;t<term_cnt;t++) FOLLOW[i][t]=false;

    FOLLOW[0][ term_index[(unsigned char)'$'] ] = true;

    bool changed = true;
    while (changed){
        changed = false;
        for (int p=0;p<prod_count;p++){
            int A = nt_index[(unsigned char)prods[p].lhs];
            for (int a=0;a<prods[p].n_alts;a++){
                const char *alpha = prods[p].rhs[a];
                int L = (int)strlen(alpha);
                for (int i=0;i<L;i++){
                    char Bc = alpha[i];
                    if (!is_nonterminal(Bc)) continue;
                    int B = nt_index[(unsigned char)Bc];
                    bool temp_terms[MAX_TERMS];
                    bool eps=false;
                    if (i+1<L){
                        eps = first_of_sequence(alpha+i+1, temp_terms);
                        for (int t=0;t<term_cnt;t++){
                            if (temp_terms[t] && !FOLLOW[B][t]){
                                FOLLOW[B][t]=true; changed=true;
                            }
                        }
                    } else eps=true;
                    if (eps){
                        for (int t=0;t<term_cnt;t++){
                            if (FOLLOW[A][t] && !FOLLOW[B][t]){
                                FOLLOW[B][t]=true; changed=true;
                            }
                        }
                    }
                }
            }
        }
    }
}

static void build_parse_table(void){
    for (int i=0;i<nt_cnt;i++)
        for (int t=0;t<term_cnt;t++){
            table_filled[i][t]=false;
            parse_table[i][t][0]='\0';
        }

    for (int p=0;p<prod_count;p++){
        int A = nt_index[(unsigned char)prods[p].lhs];
        for (int a=0;a<prods[p].n_alts;a++){
            const char *alpha = prods[p].rhs[a];
            bool temp_terms[MAX_TERMS];
            bool eps = first_of_sequence(alpha, temp_terms);
            for (int t=0;t<term_cnt;t++){
                if (term_list[t]=='$') continue;
                if (temp_terms[t]){
                    if (!table_filled[A][t]){
                        strncpy(parse_table[A][t], alpha, MAX_RHS-1);
                        table_filled[A][t]=true;
                    }
                }
            }
            if (eps){
                for (int t=0;t<term_cnt;t++){
                    if (FOLLOW[A][t]){
                        if (!table_filled[A][t]){
                            strncpy(parse_table[A][t], "e", MAX_RHS-1);
                            table_filled[A][t]=true;
                        }
                    }
                }
            }
        }
    }
}

static void print_sets(void){
    for (int i=0;i<nt_cnt;i++){
        printf("FIRST(%c) = {", nt_list[i]);
        bool printed=false;
        for (int t=0;t<term_cnt;t++){
            if (term_list[t]=='$') continue;
            if (FIRST[i][t]){
                if (printed) printf(", ");
                printf("%c", term_list[t]); printed=true;
            }
        }
        if (FIRST[i][MAX_TERMS]){
            if (printed) printf(", ");
            printf("e");
        }
        printf("}\n");
    }
    for (int i=0;i<nt_cnt;i++){
        printf("FOLLOW(%c) = {", nt_list[i]);
        bool printed=false;
        for (int t=0;t<term_cnt;t++){
            if (FOLLOW[i][t]){
                if (printed) printf(", ");
                printf("%c", term_list[t]); printed=true;
            }
        }
        printf("}\n");
    }
}

static void print_table(void){
    printf("\nPredictive Parse Table\n");
    printf("%-6s"," ");
    for (int t=0;t<term_cnt;t++) printf("%-10c", term_list[t]);
    printf("\n");
    for (int i=0;i<nt_cnt;i++){
        printf("%-6c", nt_list[i]);
        for (int t=0;t<term_cnt;t++){
            if (table_filled[i][t])
                printf("%c->%-8s", nt_list[i], parse_table[i][t]);
            else
                printf("%-10s","");
        }
        printf("\n");
    }
}

int main(void){
    // Hardcoded grammar (left-recursion-free)
    const char *grammar[] = {
        "E->TR",
        "R->+TR|e",
        "T->FY",
        "Y->*FY|e",
        "F->(E)|i"
    };
    int n = sizeof(grammar)/sizeof(grammar[0]);

    memset(nt_present,0,sizeof(nt_present));
    prod_count=0;

    for (int i=0;i<n;i++){
        const char *line = grammar[i];
        char A = line[0];
        add_nt(A);
        prods[prod_count].lhs = A;
        prods[prod_count].n_alts=0;
        const char *arrow = strstr(line,"->");
        const char *rhs = arrow+2;
        const char *p=rhs;
        char buf[MAX_RHS]; int bi=0;
        while (1){
            char c=*p;
            if (c=='|'||c=='\0'){
                buf[bi]='\0';
                if (bi>0){
                    strncpy(prods[prod_count].rhs[prods[prod_count].n_alts],buf,MAX_RHS-1);
                    prods[prod_count].n_alts++;
                }
                bi=0;
                if (c=='\0') break;
                p++; continue;
            } else {
                if (bi<MAX_RHS-1) buf[bi++]=c;
                p++;
            }
        }
        prod_count++;
    }

    compute_symbol_sets();
    init_indices();
    compute_first();
    compute_follow();
    build_parse_table();
    print_sets();
    print_table();
    return 0;
}
