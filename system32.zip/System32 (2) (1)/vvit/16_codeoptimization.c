#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int is_number(const char *s) {
    for (int i = 0; s[i]; i++) {
        if (!isdigit(s[i]) && !(i == 0 && s[i] == '-')) return 0;
    }
    return 1;
}
void optimize_line(char *line) {
    char lhs[20], op1[20], op2[20], result[20], operator;
    if (sscanf(line, "%s = %s %c %s", lhs, op1, &operator, op2) == 4) {
        if (is_number(op1) && is_number(op2)) {
            int val1 = atoi(op1), val2 = atoi(op2), res;
            if (operator == '+') res = val1 + val2;
            else if (operator == '-') res = val1 - val2;
            else if (operator == '*') res = val1 * val2;
            else if (operator == '/' && val2 != 0) res = val1 / val2;
            else {
                printf("%s", line);
                return;
            }
            printf("%s = %d\n", lhs, res);
        } else if (operator == '+' && (strcmp(op1, "0") == 0)) {
            printf("%s = %s\n", lhs, op2);
        } else if (operator == '+' && (strcmp(op2, "0") == 0)) {
            printf("%s = %s\n", lhs, op1);
        } else if (operator == '*' && (strcmp(op1, "1") == 0)) {
            printf("%s = %s\n", lhs, op2);
        } else if (operator == '*' && (strcmp(op2, "1") == 0)) {
            printf("%s = %s\n", lhs, op1);
        } else if (operator == '*' && (strcmp(op1, "0") == 0 || strcmp(op2, "0") == 0)) {
            printf("%s = 0\n", lhs);
        } else if (operator == '*' && (strcmp(op1, "2") == 0)) {
            printf("%s = %s + %s\n", lhs, op2, op2);
        } else if (operator == '*' && (strcmp(op2, "2") == 0)) {
            printf("%s = %s + %s\n", lhs, op1, op1);
        } else {
            printf("%s", line);
        }
    } else {
        printf("%s", line);
    }
}

int main() {
    FILE *fp = fopen("input.txt", "r");
    if (!fp) {
        printf("Cannot open input.txt\n");
        return 1;
    }
    char line[100];
    while (fgets(line, sizeof(line), fp)) {
        optimize_line(line);
    }
    fclose(fp);
    return 0;
}