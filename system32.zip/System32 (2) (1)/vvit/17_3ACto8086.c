#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void generate_assembly(char *line) {
    char lhs[20], op1[20], op2[20], operator;
    int n = sscanf(line, "%s = %s %c %s", lhs, op1, &operator, op2);
    if (n == 4) {
        printf("MOV AX, %s\n", op1);
        switch (operator) {
            case '+': printf("ADD AX, %s\n", op2); break;
            case '-': printf("SUB AX, %s\n", op2); break;
            case '*': printf("MUL %s\n", op2); break;
            case '/': printf("DIV %s\n", op2); break;
        }
        printf("MOV %s, AX\n\n", lhs);
    }
    else if (sscanf(line, "%s = %s", lhs, op1) == 2) {
        printf("MOV AX, %s\n", op1);
        printf("MOV %s, AX\n\n", lhs);
    }
}
int main() {
    FILE *fp = fopen("tac_input.txt", "r");
    if (!fp) {
        printf("Cannot open tac_input.txt\n");
        return 1;
    }
    char line[100];
    while (fgets(line, sizeof(line), fp)) {
        if (strlen(line) > 1) {
            generate_assembly(line);
        }
    }
    fclose(fp);
    return 0;
}