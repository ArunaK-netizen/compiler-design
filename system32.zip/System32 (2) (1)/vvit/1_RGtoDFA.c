#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_STATES 10
#define MAX_ALPHABET 10
#define MAX_STRING 100
typedef struct {
int num_states;
int num_alphabet;
int start_state;
int final_states[MAX_STATES];
int num_final_states;
int transition_table[MAX_STATES][MAX_ALPHABET];
char alphabet[MAX_ALPHABET];
} DFA;
void initializeDFA(DFA *dfa) {
dfa->num_states = 0;
dfa->num_alphabet = 0;
dfa->start_state = 0;
dfa->num_final_states = 0;
for (int i = 0; i < MAX_STATES; i++) {
for (int j = 0; j < MAX_ALPHABET; j++) {
dfa->transition_table[i][j] = -1;
}
dfa->final_states[i] = 0;
}
}
void inputDFA(DFA *dfa) {
printf("Enter number of states: ");
scanf("%d", &dfa->num_states);
printf("Enter number of alphabet symbols: ");
scanf("%d", &dfa->num_alphabet);
printf("Enter alphabet symbols: ");
for (int i = 0; i < dfa->num_alphabet; i++) {
scanf(" %c", &dfa->alphabet[i]);
}
printf("Enter start state (0 to %d): ", dfa->num_states - 1);
scanf("%d", &dfa->start_state);
printf("Enter number of final states: ");
scanf("%d", &dfa->num_final_states);
printf("Enter final states: ");
for (int i = 0; i < dfa->num_final_states; i++) {
int state;
scanf("%d", &state);
dfa->final_states[state] = 1;
}
printf("\nEnter transition table:\n");
printf("Format: current_state input_symbol next_state\n");
printf("Enter -1 -1 -1 to stop\n");
int curr_state, next_state;
char input_symbol;
while (1) {
printf("Enter transition: ");
scanf("%d", &curr_state);
if (curr_state == -1) break;
scanf(" %c %d", &input_symbol, &next_state);
// Find alphabet index
int alphabet_index = -1;
for (int i = 0; i < dfa->num_alphabet; i++) {
if (dfa->alphabet[i] == input_symbol) {
alphabet_index = i;
break;
}
}
if (alphabet_index != -1) {
dfa->transition_table[curr_state][alphabet_index] = next_state;
}
}
}
void displayTransitionTable(DFA *dfa) {
printf("\n--- TRANSITION TABLE ---\n");
printf("State\t");
for (int i = 0; i < dfa->num_alphabet; i++) {
printf("%c\t", dfa->alphabet[i]);
}
printf("\n");
for (int i = 0; i < dfa->num_states; i++) {
if (i == dfa->start_state && dfa->final_states[i]) {
printf("→*q%d\t", i);
} else if (i == dfa->start_state) {
printf("→q%d\t", i);
} else if (dfa->final_states[i]) {
printf("*q%d\t", i);
} else {
printf("q%d\t", i);
}
for (int j = 0; j < dfa->num_alphabet; j++) {
if (dfa->transition_table[i][j] != -1) {
printf("q%d\t", dfa->transition_table[i][j]);
} else {
printf("-\t");
}
}
printf("\n");
}
printf("→ : Start State, * : Final State\n");
}
int findAlphabetIndex(DFA *dfa, char symbol) {
for (int i = 0; i < dfa->num_alphabet; i++) {
if (dfa->alphabet[i] == symbol) {
return i;
}
}
return -1;
}
int simulateDFA(DFA *dfa, char *input_string) {
int current_state = dfa->start_state;
int string_length = strlen(input_string);
printf("\n--- TRANSITION SEQUENCE ---\n");
printf("Input String: %s\n", input_string);
printf("Starting from state q%d\n", current_state);
for (int i = 0; i < string_length; i++) {
char current_char = input_string[i];
int alphabet_index = findAlphabetIndex(dfa, current_char);
if (alphabet_index == -1) {
printf("Invalid character '%c' found in input string!\n", current_char);
return 0;
}
int next_state = dfa->transition_table[current_state][alphabet_index];
if (next_state == -1) {
printf("δ(q%d, %c) = undefined (No transition)\n", current_state, current_char);
printf("String REJECTED!\n");
return 0;
}
printf("δ(q%d, %c) = q%d\n", current_state, current_char, next_state);
current_state = next_state;
}
printf("Final state: q%d\n", current_state);
if (dfa->final_states[current_state]) {
printf("String ACCEPTED! (Final state is accepting)\n");
return 1;
} else {
printf("String REJECTED! (Final state is not accepting)\n");
return 0;
}
}
void testStrings(DFA *dfa) {
char input_string[MAX_STRING];
char choice;
do {
printf("\nEnter string to test: ");
scanf("%s", input_string);
simulateDFA(dfa, input_string);
printf("\nDo you want to test another string? (y/n): ");
scanf(" %c", &choice);
} while (choice == 'y' || choice == 'Y');
}
int main() {
DFA dfa;
printf("=== DFA Implementation ===\n");
printf("This program implements a Deterministic Finite Automaton\n");
printf("from regular grammar and tests string acceptance.\n\n");
initializeDFA(&dfa);
inputDFA(&dfa);
displayTransitionTable(&dfa);
testStrings(&dfa);
return 0;
}