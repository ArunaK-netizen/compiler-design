#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX_TOKENS 100

// Function to check if a string is a keyword
int isKeyword(const char* str) {
    const char* keywords[] = {"int", "float", "if", "return", NULL};
    for (int i = 0; keywords[i] != NULL; i++) {
        if (strcmp(str, keywords[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

// Lexical Analyzer
void parse(const char* input,
           char keywords[MAX_TOKENS][50], int* kwCount,
           char identifiers[MAX_TOKENS][50], int* idCount,
           char operators[MAX_TOKENS][5], int* opCount,
           char integers[MAX_TOKENS][50], int* intCount,
           char reals[MAX_TOKENS][50], int* realCount) {

    char token[50];
    int i = 0, j = 0;

    while (input[i] != '\0') {
        if (isspace(input[i])) {
            i++;
            continue;
        }

        // Identifiers and Keywords
        if (isalpha(input[i])) {
            j = 0;
            while (isalnum(input[i]) || input[i] == '_') {
                token[j++] = input[i++];
            }
            token[j] = '\0';

            if (isKeyword(token)) {
                strcpy(keywords[(*kwCount)++], token);
            } else {
                strcpy(identifiers[(*idCount)++], token);
            }

        // Integer and Real Constants
        } else if (isdigit(input[i])) {
            j = 0;
            while (isdigit(input[i])) {
                token[j++] = input[i++];
            }

            if (input[i] == '.') {
                token[j++] = input[i++];
                while (isdigit(input[i])) {
                    token[j++] = input[i++];
                }
            }

            token[j] = '\0';

            if (strchr(token, '.')) {
                strcpy(reals[(*realCount)++], token);
            } else {
                strcpy(integers[(*intCount)++], token);
            }

        // Operators
        } else if (strchr("=+-*/<>!&|", input[i])) {
            j = 0;
            token[j++] = input[i++];
            token[j] = '\0';
            strcpy(operators[(*opCount)++], token);
        }

        // Unrecognized characters
        else {
            i++;
        }
    }
}

void printTokens(char keywords[MAX_TOKENS][50], int kwCount,
                 char identifiers[MAX_TOKENS][50], int idCount,
                 char operators[MAX_TOKENS][5], int opCount,
                 char integers[MAX_TOKENS][50], int intCount,
                 char reals[MAX_TOKENS][50], int realCount) {

    printf("LEXICAL ANALYSIS\n");

    printf("Keywords: ");
    for (int i = 0; i < kwCount; i++) printf("%s ", keywords[i]);
    printf("\n");

    printf("Identifiers: ");
    for (int i = 0; i < idCount; i++) printf("%s ", identifiers[i]);
    printf("\n");

    printf("Operators: ");
    for (int i = 0; i < opCount; i++) printf("%s ", operators[i]);
    printf("\n");

    printf("Integers: ");
    for (int i = 0; i < intCount; i++) printf("%s ", integers[i]);
    printf("\n");

    printf("Real Numbers: ");
    for (int i = 0; i < realCount; i++) printf("%s ", reals[i]);
    printf("\n");
}

int main() {
    char input[100] = "int d = c*b + 2.0*e;";
    
    char keywords[MAX_TOKENS][50], identifiers[MAX_TOKENS][50];
    char operators[MAX_TOKENS][5], integers[MAX_TOKENS][50], reals[MAX_TOKENS][50];
    int kwCount = 0, idCount = 0, opCount = 0, intCount = 0, realCount = 0;

    parse(input, keywords, &kwCount, identifiers, &idCount,
          operators, &opCount, integers, &intCount, reals, &realCount);

    printTokens(keywords, kwCount, identifiers, idCount,
                operators, opCount, integers, intCount, reals, realCount);

    return 0;
}