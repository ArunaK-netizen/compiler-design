#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX_TOKENS 100

// Function to check if a string is a keyword
int isKeyword(const char* str) {
    const char* keywords[] = {"int", "float", "if", "return", NULL};
    for (int i = 0; keywords[i] != NULL; i++) {
        if (strcmp(str, keywords[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

void parse(const char* input, char keywords[MAX_TOKENS][50], int* kwCount,
           char identifiers[MAX_TOKENS][50], int* idCount,
           char operators[MAX_TOKENS][5], int* opCount,
           char integers[MAX_TOKENS][50], int* intCount,
           char reals[MAX_TOKENS][50], int* realCount) {

    char token[50];
    int i = 0, j = 0;

    while (input[i] != '\0') {
        if (isspace(input[i])) {
            i++;
            continue;
        }

        // Identify keywords and identifiers
        if (isalpha(input[i])) {
            j = 0;
            while (isalnum(input[i]) || input[i] == '_') {
                token[j++] = input[i++];
            }
            token[j] = '\0';

            if (isKeyword(token)) {
                strcpy(keywords[(*kwCount)++], token);
            } else {
                strcpy(identifiers[(*idCount)++], token);
            }
        }

        // Identify integers and real numbers
        else if (isdigit(input[i])) {
            j = 0;
            while (isdigit(input[i])) {
                token[j++] = input[i++];
            }

            if (input[i] == '.') {
                token[j++] = input[i++];
                while (isdigit(input[i])) {
                    token[j++] = input[i++];
                }
            }

            token[j] = '\0';

            if (strchr(token, '.')) {
                strcpy(reals[(*realCount)++], token);
            } else {
                strcpy(integers[(*intCount)++], token);
            }
        }

        // Identify operators
        else if (strchr("=+-*/<>!&|", input[i])) {
            j = 0;
            token[j++] = input[i++];
            token[j] = '\0';
            strcpy(operators[(*opCount)++], token);
        } else {
            i++;
        }
    }
}

// Function to print categorized tokens
void printTokens(char keywords[MAX_TOKENS][50], int kwCount,
                 char identifiers[MAX_TOKENS][50], int idCount,
                 char operators[MAX_TOKENS][5], int opCount,
                 char integers[MAX_TOKENS][50], int intCount,
                 char reals[MAX_TOKENS][50], int realCount) {

    printf("Keywords: ");
    for (int i = 0; i < kwCount; i++) printf("%s ", keywords[i]);
    printf("\n");

    printf("Identifiers: ");
    for (int i = 0; i < idCount; i++) printf("%s ", identifiers[i]);
    printf("\n");

    printf("Operators: ");
    for (int i = 0; i < opCount; i++) printf("%s ", operators[i]);
    printf("\n");

    printf("Integers: ");
    for (int i = 0; i < intCount; i++) printf("%s ", integers[i]);
    printf("\n");

    printf("Real Numbers: ");
    for (int i = 0; i < realCount; i++) printf("%s ", reals[i]);
    printf("\n");
}

int main() {
    FILE* le = fopen("input.txt", "r");
    if (le == NULL) {
        printf("Error opening file!\n");
        return 1;
    }

    char input[1000]; // Input buffer to hold the file content

    char keywords[MAX_TOKENS][50], identifiers[MAX_TOKENS][50],
         operators[MAX_TOKENS][5], integers[MAX_TOKENS][50], reals[MAX_TOKENS][50];

    int kwCount = 0, idCount = 0, opCount = 0, intCount = 0, realCount = 0;

    while (fgets(input, sizeof(input), le)) {
        parse(input, keywords, &kwCount, identifiers, &idCount, operators, &opCount,
              integers, &intCount, reals, &realCount);
    }

    fclose(le);

    printTokens(keywords, kwCount, identifiers, idCount, operators, opCount, integers,
                intCount, reals, realCount);

    return 0;
}